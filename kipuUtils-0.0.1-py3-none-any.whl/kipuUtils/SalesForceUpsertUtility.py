import os

from kipuUtils.AbstractSalesForceUtility import AbstractSalesForceUtility


class SalesForceUpsertUtility(AbstractSalesForceUtility):

    def __init__(self, object_name, external_id_field):

        line_ending = "LF"
        if os.name == 'nt':
            line_ending = "CRLF"
        self.create_job_payload = {
            "object": object_name,
            "externalIdFieldName": external_id_field,
            "contentType": "CSV",
            "operation": "upsert",
            "lineEnding": line_ending
        }
        AbstractSalesForceUtility.__init__(self, create_job_payload=self.create_job_payload)
