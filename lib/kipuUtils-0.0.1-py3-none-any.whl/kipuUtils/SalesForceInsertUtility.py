import os

from kipuUtils.AbstractSalesForceUtility import AbstractSalesForceUtility


class SalesForceInsertUtility(AbstractSalesForceUtility):
    def __init__(self, object_name):
        line_ending = "LF"
        if os.name == 'nt':
            line_ending = "CRLF"
        create_job_payload = {
            "object": object_name,
            "contentType": "CSV",
            "operation": "insert",
            "lineEnding": line_ending
        }
        super().__init__(create_job_payload)
