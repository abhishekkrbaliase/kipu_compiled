import email
import imaplib
import time


class KipuOTPUtil:
    def __init__(self):
        pass

    @staticmethod
    def get_otp_from_email(username, password, imap_server):
        print("Getting OTP")
        imap = imaplib.IMAP4_SSL(imap_server)
        time.sleep(5)
        imap.login(username, password)
        imap.select("inbox")
        status, data = imap.search(None, '(SUBJECT "Kipu Authentication Code")')
        for num in data[0].split():
            status, data = imap.fetch(num, "(RFC822)")
            email_message = email.message_from_bytes(data[0][1])
            # print("From:", email_message["From"])
            # print("Subject:", email_message["Subject"])
            # print("Date:", email_message["Date"])
            # print("Body:", email_message.get_payload())
            body = email_message.get_payload()
            otp = body.split('Your Kipu Systems Security code is')[1].strip()
        print("OTP fetched " + otp)
        return otp

    @staticmethod
    def get_otp_from_email_from_conf(config):
        return KipuOTPUtil.get_otp_from_email(config['otp_email_username'], config['otp_email_password'], config['otp_email_imap_server'])
