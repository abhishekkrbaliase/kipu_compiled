import json
import logging
import os
import tempfile
import time
from abc import ABC

import requests


def get_salesforce_token(consumer_key, consumer_secret,
                         base_url="https://sunshinebhcllc--auditdev.sandbox.my.salesforce.com"):
    params = {'grant_type': 'client_credentials', 'client_id': consumer_key, 'client_secret': consumer_secret}
    response = requests.request("GET", base_url + '/services/oauth2/token', params=params)
    if response.status_code is 200:
        values = response.json()
        response.close()
        return values['access_token']
    else:
        print(' Failed to get Salesforce Auth Token Base URL {} consumer_key {}  Error:\n{} '
              .format(base_url, consumer_key, response.content))
    return None


class AbstractSalesForceUtility(ABC):
    __logger = logging.getLogger('AbstractSalesForceUtility')

    def __init__(self, create_job_payload):
        self.create_job_payload = create_job_payload

    def __get_new_salesforce_job_id(self, auth_token,
                                    base_url="https://sunshinebhcllc--auditdev.sandbox.my.salesforce.com"):
        headers = {
            'Authorization': 'Bearer {0}'.format(auth_token),
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        response = requests.request("POST", base_url + '/services/data/v57.0/jobs/ingest/', headers=headers,
                                    data=json.dumps(self.create_job_payload))
        if response.status_code is 200:
            values = response.json()
            response.close()
            return values['id']
        else:
            print('Failed to get Salesforce Job Id for Params {}. Error:\n{}'
                  .format(self.create_job_payload, response.content))
        return None

    def __push_to_salesforce(self, temp_file_csv_file, auth_token,
                             base_url="https://sunshinebhcllc--auditdev.sandbox.my.salesforce.com",
                             job_id=None):
        if not job_id:
            job_id = self.__get_new_salesforce_job_id(auth_token, base_url)
        if not job_id:
            return 'missingAuth'
        insert_service_path = "/services/data/v57.0/jobs/ingest/{0}/batches".format(job_id)
        close_job_path = job_status_path = "/services/data/v57.0/jobs/ingest/{0}/".format(job_id)
        close_job_body = '{ "state" : "UploadComplete" }'

        # Insert
        headers = {
            'Authorization': 'Bearer {0}'.format(auth_token),
            'Content-Type': 'text/csv',
            'Accept': 'application/json'
        }

        with open(temp_file_csv_file.name, 'rb') as payload:
            response = requests.request("PUT", base_url + insert_service_path, headers=headers, data=payload)
            response.close()

        headers['Content-Type'] = "application/json"
        response = requests.request("PATCH", base_url + close_job_path, headers=headers, data=close_job_body)
        response.close()

        job_completed = False
        while not job_completed:
            time.sleep(3)
            print("Current job status is: ")
            if 'Content-Type' in headers:
                headers.pop('Content-Type')
            response = requests.request("GET", headers=headers, url=base_url + job_status_path)
            value = response.json()
            response.close()
            print(value['state'])
            self.__logger.debug("Salesforce job id is {}", str(job_id))
            if value['state'] == 'JobComplete' and int(value["numberRecordsFailed"]) == 0:
                print("Inserted {} records to Salesforce with JobID {}\n".format(value['numberRecordsProcessed'], job_id))
                return 'Success'
            if value['state'] == 'Failed' or int(value["numberRecordsFailed"]) > 0:
                print("Insert to Salesforce job {} Failed", job_id)
                return 'Failed'

    def write_records(self, pandas_df, consumer_key, consumer_secret,
                      base_url="https://sunshinebhcllc--auditdev.sandbox.my.salesforce.com"):
        processed = False
        _tempFile = tempfile.NamedTemporaryFile(delete=False)
        pandas_df.to_csv(_tempFile, line_terminator=os.linesep, index=False)
        while not processed:
            auth_token = get_salesforce_token(consumer_key, consumer_secret, base_url)
            ret_st = self.__push_to_salesforce(_tempFile, auth_token, base_url)
            if ret_st == 'missingAuth':
                continue
            else:
                print("<=========== Processing Done =========> \n")
                print("<===== Processing Status : {} ===>".format(ret_st))
                processed = True
        _tempFile.close()
        os.remove(_tempFile.name)
        return processed

    def write_records_using_conf(self, pandas_df, configs):
        return self.write_records(pandas_df,
                                  configs['Salesforce_Consumer_Key'].strip(),
                                  configs['Salesforce_Consumer_Secret'].strip(),
                                  configs['Salesforce_URL'].strip()
                                  )
