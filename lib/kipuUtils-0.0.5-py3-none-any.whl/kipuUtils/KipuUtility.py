import logging
import os
import re
import sys
import time
from logging.handlers import RotatingFileHandler

from selenium.webdriver import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from kipuUtils.KipuOTPUtil import KipuOTPUtil


class KipuUtility:
    configs = {}

    url_mappings = {
        "CC": "https://chapterscapistrano.kipuworks.com",
        "WSR": "https://willowspringsrecovery.kipuworks.com",
        "MSR": "https://sunshinebehavioral.kipuworks.com",
        "MS": "https://monarchshores.kipuworks.com",
        "LR": "https://sunshinebehavioral.kipuworks.com"
    }

    __logger = logging.getLogger('KipuUtility')
    logging_level_set = {
        "DEBUG": logging.DEBUG,
        "INFO": logging.INFO
    }

    base_url = None

    def get_config(self):
        return self.configs

    def login(self, browser, automated_otp=True):
        centre_selected = False
        selected_centre = ''
        centre_selected_str = self.configs.get('selected_centre', None)
        if not centre_selected_str:
            while centre_selected is False:
                print("Enter Kipu Centre Code. Example - CC / WSR / MSR / MS / LR")
                selected_centre = input()
                try:
                    selected_centre = selected_centre.strip()
                    self.base_url = self.configs[selected_centre + '_URL']
                    centre_selected = True
                except KeyError:
                    print("Invalid Centre Entered. Selected Center not configured")
        else:
            selected_centre = centre_selected_str.strip()
            print("Selected Centre : {}".format(selected_centre))
            self.base_url = self.configs[selected_centre + '_URL']
        try:
            email_id = self.configs[selected_centre + '_Username'].strip()
            password = self.configs[selected_centre + '_Password'].strip()
        except KeyError as e:
            print(
                "{} not provided. Shutting Down. Please configure the file and start the application".format(e.args[0]))
            browser.close()
            sys.exit(1)
        browser.get(self.base_url + "/users/sign_in")

        if 'sign_in' in browser.current_url:
            email = browser.find_element(By.ID, "user_login")
            email.send_keys(email_id)  # "deepakk@sunshinebh.com"

            password_box = browser.find_element(By.ID, "user_password")
            password_box.send_keys(password)
            password_box.send_keys(Keys.RETURN)

        if 'sign_in' in browser.current_url:
            self.__logger.debug(""" User still didn't get signed-in after entering credentials8x8""")
            print('Sign-In failed. Check Credentials')
            self.__logger.error('Sign-In failed. Check Credentials')
            browser.quit()
            sys.exit(1)

        if "password_expired" in browser.current_url:
            print("Password expired. Please reset it and configure in the file")
            self.__logger.info("Password expired. Please reset it and configure in the file")
            browser.quit()
            sys.exit(1)

        print("Checking for Two Factor Authentication")
        is_two_factor_page = "two_factor_authentication" in browser.current_url

        while is_two_factor_page:
            hrefs = browser.find_elements(By.TAG_NAME, "a")
            for href in hrefs:
                if href.get_attribute("href") and "send_code" in href.get_attribute("href"):
                    href.click()
                    break
            otp = None
            try:
                otp = KipuOTPUtil.get_otp_from_email_from_conf(self.configs)
            except Exception as ex1:
                print("Enter OTP")
                otp = input()
            otp_box = browser.find_element(By.ID, "code")
            otp_box.send_keys(otp)
            otp_box.send_keys(Keys.RETURN)
            is_two_factor_page = "two_factor_authentication" in browser.current_url

        print("Logged in to Kipu..")

        if selected_centre == 'LR':  # Default dropdown is LR (Lincoln Recovery)
            browser.maximize_window()
            browser.find_element(By.ID, 'switch_my_location').click()
            time.sleep(2)
            all_dropdown = browser.find_elements(By.TAG_NAME, 'li')
            for dd in all_dropdown:
                if 'Lincoln Recovery' in dd.text:
                    dd.click()
                    break
        elif selected_centre == 'MSR':  # Default dropdown is LR (Lincoln Recovery)
            browser.maximize_window()
            browser.find_element(By.ID, 'switch_my_location').click()
            time.sleep(2)
            all_dropdown = browser.find_elements(By.TAG_NAME, 'li')
            for dd in all_dropdown:
                if 'Mountain Springs Recovery' in dd.text:
                    dd.click()
                    break
        try:
            # close notification enable popup
            popup = browser.find_element(By.ID, "headlessui-dialog-panel-3")
            popup.find_elements(By.TAG_NAME, "button")[1].click()
        except Exception as ex:
            pass
        return self.base_url, selected_centre

    def search_mrn(self, browser_ptr, patient_mrn_entered, kipu_base_url):
        browser_ptr.get(kipu_base_url + "/patients")
        patient_id = None
        search_box = browser_ptr.find_element(By.ID, "term_form")
        search_box.send_keys(patient_mrn_entered)
        search_box.send_keys(Keys.RETURN)
        if len(browser_ptr.find_elements("xpath", "//*[text()[contains(.,'no records found')]]")) > 0:
            print("MRN not found {0}".format(patient_mrn_entered))
            return None
        is_next_present = True
        while is_next_present:
            search_table_data = browser_ptr.find_element(By.ID, "patient_search_result")
            all_tr = search_table_data.find_elements(By.TAG_NAME, "tr")
            for tr in all_tr:
                if patient_mrn_entered in tr.text.split():
                    patient_search_href = tr.find_element(By.TAG_NAME, "a")
                    if patient_search_href.get_attribute("href") and "/patients/" in patient_search_href.get_attribute(
                            "href"):
                        patient_id = patient_search_href.get_attribute("href").split("/patients/", 1)[1]
                        browser_ptr.get(kipu_base_url + "/patients/" + patient_id)
                        is_next_present = False  # Don't loop again
                        break
            if not patient_id:
                next_button = browser_ptr.find_element(By.ID, "patient_search_result_paginate") \
                    .find_element("xpath", "//*[contains(text(),'Next')]")
                is_next_present = 'disabled' not in next_button.get_attribute('class')
                if is_next_present:
                    element = WebDriverWait(browser_ptr, 60).until(
                        EC.element_to_be_clickable((By.XPATH, "//*[contains(text(),'Next')]")))
                    browser_ptr.execute_script("window.scrollTo(0, document.body.scrollHeight);")  # Scroll Down
                    try:
                        element.click()
                    except Exception:
                        element.click()  # As it might not be clickable earlier, click again

        if not patient_id:
            print("MRN not found {0}".format(patient_mrn_entered))
            return None
        return patient_id

    def set_logger(self, level=None):
        if level:
            self.__logger.setLevel(self.logging_level_set[level])
        else:
            self.__logger.setLevel(self.logging_level_set["INFO"])
        file_handler = RotatingFileHandler(os.path.dirname(sys.argv[1]) + os.path.sep + "logs.log",
                                           maxBytes=1024 * 1024 * 10,
                                           backupCount=3)  # abhishek - remove console logging
        logging.basicConfig(
            format='%(asctime)s %(levelname)-8s %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S')
        self.__logger.addHandler(file_handler)

    def get_logger(self, level=None):
        self.set_logger(level)
        return self.__logger

    def load_configs(self, config_path):
        with open(config_path, "r") as f:
            for line in f.readlines():
                line_str = line.split(':', 1)  # split on first occurrence only
                if len(line_str) != 2:
                    continue
                self.configs[str(line_str[0]).strip()] = str(line_str[1]).strip()

    def __init__(self, config_file_path):
        self.load_configs(config_file_path)

        # iterate url_mappings and add to self.config as key and value
        self.configs.update({key + '_URL': value for key, value in self.url_mappings.items()})

        # if sys.argv start with --conf then upsert next value into self.configs
        i = 1
        while i < len(sys.argv):
            if sys.argv[i] == "--conf":
                result = re.split('[:=]', sys.argv[i + 1], maxsplit=1)
                self.configs[result[0]] = ''.join(result[1:])
            i = i + 1

    def get_input(self, config_key, console_print_statement):
        if config_key in self.configs:
            return self.configs[config_key]
        else:
            print(console_print_statement)
            return input()