import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from chromedriver_py import binary_path


class BrowserUtility:
    def __init__(self):
        pass

    @staticmethod
    def get_browser(chrome_options=None, cookies_list_of_dict=None, debug=None):
        if not chrome_options:
            chrome_options = Options()
            if not debug:
                chrome_options.headless = True
            chrome_options.add_argument("--window-size=1920,1080")
        chrome_options.add_experimental_option("excludeSwitches", ['enable-logging'])
        driver = webdriver.Chrome(service=Service(binary_path),
                                  options=chrome_options, service_log_path=os.devnull)

        # Iterate through dict and add all the cookies
        if cookies_list_of_dict:
            driver.execute_cdp_cmd('Network.enable', {})
            for cookie in cookies_list_of_dict:
                # Fix issue Chrome exports 'expiry' key but expects 'expire' on import
                if 'expiry' in cookie:
                    cookie['expires'] = cookie['expiry']
                    del cookie['expiry']
                # Set the actual cookie
                driver.execute_cdp_cmd('Network.setCookie', cookie)
            # Disable network tracking
            driver.execute_cdp_cmd('Network.disable', {})
        return driver
